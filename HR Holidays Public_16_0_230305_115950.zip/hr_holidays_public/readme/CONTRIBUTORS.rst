* Michael Telahun Makonnen <mmakonnen@gmail.com>
* Fekete Mihai <feketemihai@gmail.com>
* Nikolina Todorova <nikolina.todorova@initos.com>
* Alexis de Lattre <alexis.delattre@akretion.com>
* Salton Massally (iDT Labs) <smassally@idtlabs.sl>
* Ivan Yelizariev <yelizariev@it-projects.info>
* Bassirou Ndaw <b.ndaw@ergobit.org>
* Dhara Solanki <dhara.solanki@initos.com>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza

* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>

* `Camptocamp <https://www.camptocamp.com>`__:

  * Damien Crier <damien.crier@camptocamp.com>

* `Druidoo <https://www.druidoo.io>`__:

  * Iván Todorovich <ivan.todorovich@gmail.com>

* `Pesol <https://www.pesol.es>`__:

  * Pedro Evaristo Gonzalez Sanchez <pedro.gonzalez@pesol.es>
